package com.example.minicampus

data class Course(
    val id: Int,
    val title: String,
    val description: String,
)
